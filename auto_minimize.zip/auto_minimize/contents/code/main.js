let lastWindow = null;
let lastStableWindow = null;

workspace.windowActivated.connect(function(window) {
    if (!window) return;

    // FILTER: hanya window normal
    if (!window.normalWindow) {
        return;
    }

    let area = workspace.clientArea(workspace.MaximizeArea, window);

    let widthRatio = window.width / area.width;
    let heightRatio = window.height / area.height;

    let isMainWindow = (widthRatio > 0.3 && heightRatio > 0.3);

    if (isMainWindow) {
        if (window === lastStableWindow) {
            lastWindow = window;
            return;
        }

        try {
            if (lastWindow &&
                lastWindow !== window &&
                !lastWindow.minimized &&
                !lastWindow.specialWindow) {

                let lastArea = workspace.clientArea(workspace.MaximizeArea, lastWindow);

                let wRatio = lastWindow.width / lastArea.width;
                let hRatio = lastWindow.height / lastArea.height;

                if (wRatio > 0.9 && hRatio > 0.9) {
                    lastWindow.minimized = true;
                }
            }

        } catch (e) { }

        lastStableWindow = window;
    }

    lastWindow = window;
});
