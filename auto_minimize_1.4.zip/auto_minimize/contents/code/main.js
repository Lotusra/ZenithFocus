let windowStack = [];
let lastWindow = null;
let activeTimer = null;

const blacklist = ["spectacle", "kaccess", "krunner", "plasmashell"];

function isValidWindow(w) {
    if (!w) return false;
    try {
        let res = w.resourceClass.toString().toLowerCase();
        if (blacklist.indexOf(res) !== -1) return false;

        let test = w.caption;
        return typeof test === "string";
    } catch (e) { return false; }
}

workspace.windowActivated.connect(function(window) {
    // Cek dulu apakah ini Spectacle
    try {
        if (window && window.resourceClass.toString().toLowerCase() === "spectacle") {
            // Jika Spectacle aktif, kita update lastWindow jadi null sementara
            // supaya script tidak memaksa balik ke aplikasi lama saat Spectacle sedang bekerja
            lastWindow = null;
            return;
        }
    } catch (e) { }

    if (!window || !window.normalWindow || !isValidWindow(window)) return;

    let area, isMainWindow;
    try {
        area = workspace.clientArea(workspace.MaximizeArea, window);
        isMainWindow = (window.width / area.width > 0.3 && window.height / area.height > 0.3);
    } catch (e) { return; }

    if (!isMainWindow || window.transient || window.dialog) return;

    let currentIndex = windowStack.indexOf(window);
    if (currentIndex === -1) {
        let activeIdx = windowStack.indexOf(lastWindow);
        if (activeIdx !== -1 && activeIdx < windowStack.length - 1) {
            windowStack.splice(activeIdx + 1, 0, window);
        } else {
            windowStack.push(window);
        }
    }

    if (activeTimer) {
        activeTimer.stop();
    }

    activeTimer = new QTimer();
    activeTimer.singleShot = true;
    activeTimer.interval = 150;
    activeTimer.timeout.connect(function() {
        windowStack.forEach(function(w) {
            if (isValidWindow(w) && w !== window && !w.minimized) {
                try {
                    let a = workspace.clientArea(workspace.MaximizeArea, w);
                    if (w.width / a.width > 0.9) {
                        w.minimized = true;
                    }
                } catch (e) { }
            }
        });
        activeTimer = null;
    });
    activeTimer.start();

    lastWindow = window;
});

workspace.windowRemoved.connect(function(window) {
    if (!window) return;

    // --- FIX SPECTACLE FOCUS ---
    try {
        if (window.resourceClass.toString().toLowerCase() === "spectacle") {
            return; // JANGAN lakukan apa-apa jika yang ditutup adalah bagian dari Spectacle
        }
    } catch (e) { }

    let index = windowStack.indexOf(window);
    if (index === -1) return;

    windowStack.splice(index, 1);

    if (window === lastWindow) {
        let targetIdx = index - 1;
        if (targetIdx < 0 && windowStack.length > 0) targetIdx = 0;

        let targetWin = windowStack[targetIdx];
        if (isValidWindow(targetWin)) {
            let rTimer = new QTimer();
            rTimer.singleShot = true;
            rTimer.interval = 100;
            rTimer.timeout.connect(function() {
                try {
                    // Cek lagi apakah sekarang Spectacle yang sedang aktif
                    // Jika iya, jangan ganggu fokusnya
                    if (workspace.activeWindow && workspace.activeWindow.resourceClass.toString().toLowerCase() === "spectacle") {
                        return;
                    }

                    if (!targetWin.minimized) return;
                    targetWin.minimized = false;
                    workspace.activeWindow = targetWin;
                    targetWin.requestActivate();
                    lastWindow = targetWin;
                } catch (e) { }
            });
            rTimer.start();
        } else {
            lastWindow = null;
        }
    }
});
